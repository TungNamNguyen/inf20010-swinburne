﻿namespace Task1INFHD
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.custidp1 = new System.Windows.Forms.TextBox();
            this.custnamep1 = new System.Windows.Forms.TextBox();
            this.prodidp3 = new System.Windows.Forms.TextBox();
            this.prodnamep3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.add_customer = new System.Windows.Forms.Button();
            this.delete_all_customers = new System.Windows.Forms.Button();
            this.add_product = new System.Windows.Forms.Button();
            this.delete_all_products = new System.Windows.Forms.Button();
            this.get_customer = new System.Windows.Forms.Button();
            this.update_customer_saleytd = new System.Windows.Forms.Button();
            this.get_product = new System.Windows.Forms.Button();
            this.update_product_saleytd = new System.Windows.Forms.Button();
            this.add_simple_sale = new System.Windows.Forms.Button();
            this.sum_customer_saleytd = new System.Windows.Forms.Button();
            this.output = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.pricep3 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.update_customer_status = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.custidp5 = new System.Windows.Forms.TextBox();
            this.custidp6 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.amountp6 = new System.Windows.Forms.TextBox();
            this.prodidp7 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.amountp8 = new System.Windows.Forms.TextBox();
            this.prodidp8 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.statusp9 = new System.Windows.Forms.TextBox();
            this.custidp9 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.qtyp10 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.prodidp10 = new System.Windows.Forms.TextBox();
            this.custidp10 = new System.Windows.Forms.TextBox();
            this.get_all_customers = new System.Windows.Forms.Button();
            this.get_all_products = new System.Windows.Forms.Button();
            this.add_complex_sale = new System.Windows.Forms.Button();
            this.get_all_sales = new System.Windows.Forms.Button();
            this.count_product_sales = new System.Windows.Forms.Button();
            this.delete_sale = new System.Windows.Forms.Button();
            this.delete_all_sales = new System.Windows.Forms.Button();
            this.delete_product = new System.Windows.Forms.Button();
            this.delete_customer = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.custidp12 = new System.Windows.Forms.TextBox();
            this.prodidp12 = new System.Windows.Forms.TextBox();
            this.qtyp12 = new System.Windows.Forms.TextBox();
            this.datep12 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.custidp17 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.prodidp18 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.daysp14 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // custidp1
            // 
            this.custidp1.Location = new System.Drawing.Point(377, 23);
            this.custidp1.Name = "custidp1";
            this.custidp1.Size = new System.Drawing.Size(100, 22);
            this.custidp1.TabIndex = 0;
            // 
            // custnamep1
            // 
            this.custnamep1.Location = new System.Drawing.Point(684, 20);
            this.custnamep1.Name = "custnamep1";
            this.custnamep1.Size = new System.Drawing.Size(100, 22);
            this.custnamep1.TabIndex = 1;
            // 
            // prodidp3
            // 
            this.prodidp3.Location = new System.Drawing.Point(377, 122);
            this.prodidp3.Name = "prodidp3";
            this.prodidp3.Size = new System.Drawing.Size(100, 22);
            this.prodidp3.TabIndex = 2;
            // 
            // prodnamep3
            // 
            this.prodnamep3.Location = new System.Drawing.Point(608, 122);
            this.prodnamep3.Name = "prodnamep3";
            this.prodnamep3.Size = new System.Drawing.Size(100, 22);
            this.prodnamep3.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Add Customer to DB (p1)";
            // 
            // add_customer
            // 
            this.add_customer.Location = new System.Drawing.Point(987, 19);
            this.add_customer.Name = "add_customer";
            this.add_customer.Size = new System.Drawing.Size(156, 23);
            this.add_customer.TabIndex = 5;
            this.add_customer.Text = "Add Customer";
            this.add_customer.UseVisualStyleBackColor = true;
            this.add_customer.Click += new System.EventHandler(this.add_customer_Click);
            // 
            // delete_all_customers
            // 
            this.delete_all_customers.Location = new System.Drawing.Point(987, 73);
            this.delete_all_customers.Name = "delete_all_customers";
            this.delete_all_customers.Size = new System.Drawing.Size(156, 23);
            this.delete_all_customers.TabIndex = 6;
            this.delete_all_customers.Text = "Delete All Customers";
            this.delete_all_customers.UseVisualStyleBackColor = true;
            this.delete_all_customers.Click += new System.EventHandler(this.delete_all_customers_Click);
            // 
            // add_product
            // 
            this.add_product.Location = new System.Drawing.Point(987, 128);
            this.add_product.Name = "add_product";
            this.add_product.Size = new System.Drawing.Size(156, 23);
            this.add_product.TabIndex = 7;
            this.add_product.Text = "Add Product";
            this.add_product.UseVisualStyleBackColor = true;
            this.add_product.Click += new System.EventHandler(this.add_product_Click);
            // 
            // delete_all_products
            // 
            this.delete_all_products.Location = new System.Drawing.Point(987, 179);
            this.delete_all_products.Name = "delete_all_products";
            this.delete_all_products.Size = new System.Drawing.Size(149, 23);
            this.delete_all_products.TabIndex = 8;
            this.delete_all_products.Text = "Delete All Products";
            this.delete_all_products.UseVisualStyleBackColor = true;
            this.delete_all_products.Click += new System.EventHandler(this.delete_all_products_Click);
            // 
            // get_customer
            // 
            this.get_customer.Location = new System.Drawing.Point(986, 233);
            this.get_customer.Name = "get_customer";
            this.get_customer.Size = new System.Drawing.Size(150, 23);
            this.get_customer.TabIndex = 9;
            this.get_customer.Text = "Get Customer";
            this.get_customer.UseVisualStyleBackColor = true;
            this.get_customer.Click += new System.EventHandler(this.get_customer_Click);
            // 
            // update_customer_saleytd
            // 
            this.update_customer_saleytd.Location = new System.Drawing.Point(987, 285);
            this.update_customer_saleytd.Name = "update_customer_saleytd";
            this.update_customer_saleytd.Size = new System.Drawing.Size(190, 23);
            this.update_customer_saleytd.TabIndex = 10;
            this.update_customer_saleytd.Text = "Update Customer SaleYTD";
            this.update_customer_saleytd.UseVisualStyleBackColor = true;
            this.update_customer_saleytd.Click += new System.EventHandler(this.update_customer_saleytd_Click);
            // 
            // get_product
            // 
            this.get_product.Location = new System.Drawing.Point(987, 340);
            this.get_product.Name = "get_product";
            this.get_product.Size = new System.Drawing.Size(111, 23);
            this.get_product.TabIndex = 11;
            this.get_product.Text = "Get Product";
            this.get_product.UseVisualStyleBackColor = true;
            this.get_product.Click += new System.EventHandler(this.get_product_Click);
            // 
            // update_product_saleytd
            // 
            this.update_product_saleytd.Location = new System.Drawing.Point(986, 396);
            this.update_product_saleytd.Name = "update_product_saleytd";
            this.update_product_saleytd.Size = new System.Drawing.Size(202, 23);
            this.update_product_saleytd.TabIndex = 12;
            this.update_product_saleytd.Text = "Update Product SaleYTD";
            this.update_product_saleytd.UseVisualStyleBackColor = true;
            this.update_product_saleytd.Click += new System.EventHandler(this.update_product_saleytd_Click);
            // 
            // add_simple_sale
            // 
            this.add_simple_sale.Location = new System.Drawing.Point(986, 500);
            this.add_simple_sale.Name = "add_simple_sale";
            this.add_simple_sale.Size = new System.Drawing.Size(150, 23);
            this.add_simple_sale.TabIndex = 13;
            this.add_simple_sale.Text = "Add Simple Sale";
            this.add_simple_sale.UseVisualStyleBackColor = true;
            this.add_simple_sale.Click += new System.EventHandler(this.add_simple_sale_Click);
            // 
            // sum_customer_saleytd
            // 
            this.sum_customer_saleytd.Location = new System.Drawing.Point(987, 548);
            this.sum_customer_saleytd.Name = "sum_customer_saleytd";
            this.sum_customer_saleytd.Size = new System.Drawing.Size(196, 23);
            this.sum_customer_saleytd.TabIndex = 14;
            this.sum_customer_saleytd.Text = "Sum Customer SaleYTD";
            this.sum_customer_saleytd.UseVisualStyleBackColor = true;
            this.sum_customer_saleytd.Click += new System.EventHandler(this.sum_customer_saleytd_Click);
            // 
            // output
            // 
            this.output.FormattingEnabled = true;
            this.output.ItemHeight = 16;
            this.output.Location = new System.Drawing.Point(1169, 20);
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(776, 180);
            this.output.TabIndex = 15;
            this.output.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(291, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "Customer ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(574, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Customer Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(207, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "Delete All Customer From DB (p2)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 16);
            this.label5.TabIndex = 19;
            this.label5.Text = "Add Product to DB (p3)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 186);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(203, 16);
            this.label6.TabIndex = 20;
            this.label6.Text = "Delete All Products From DB (p4)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 233);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(170, 16);
            this.label7.TabIndex = 21;
            this.label7.Text = "Get Customer From DB (p5)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 285);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(197, 16);
            this.label8.TabIndex = 22;
            this.label8.Text = "Update Customer SaleYTD (p6)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 340);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(159, 16);
            this.label9.TabIndex = 23;
            this.label9.Text = "Get Product From DB (p7)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 396);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(186, 16);
            this.label10.TabIndex = 24;
            this.label10.Text = "Update Product SaleYTD (p8)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 450);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(178, 16);
            this.label11.TabIndex = 25;
            this.label11.Text = "Update Customer Status (p9)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 500);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(177, 16);
            this.label12.TabIndex = 26;
            this.label12.Text = "Add Simple Sale to DB (p10)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 548);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(186, 16);
            this.label13.TabIndex = 27;
            this.label13.Text = "Sum Customer SaleYTD (p11)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(291, 125);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 16);
            this.label14.TabIndex = 28;
            this.label14.Text = "Product ID";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(509, 125);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 16);
            this.label15.TabIndex = 29;
            this.label15.Text = "Product Name";
            // 
            // pricep3
            // 
            this.pricep3.Location = new System.Drawing.Point(826, 122);
            this.pricep3.Name = "pricep3";
            this.pricep3.Size = new System.Drawing.Size(100, 22);
            this.pricep3.TabIndex = 30;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(782, 125);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 16);
            this.label16.TabIndex = 31;
            this.label16.Text = "Price";
            // 
            // update_customer_status
            // 
            this.update_customer_status.Location = new System.Drawing.Point(992, 450);
            this.update_customer_status.Name = "update_customer_status";
            this.update_customer_status.Size = new System.Drawing.Size(190, 25);
            this.update_customer_status.TabIndex = 32;
            this.update_customer_status.Text = "Update Customer Status";
            this.update_customer_status.UseVisualStyleBackColor = true;
            this.update_customer_status.Click += new System.EventHandler(this.update_customer_status_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(291, 230);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 16);
            this.label17.TabIndex = 33;
            this.label17.Text = "Customer ID";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(574, 396);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 16);
            this.label18.TabIndex = 34;
            // 
            // custidp5
            // 
            this.custidp5.Location = new System.Drawing.Point(377, 227);
            this.custidp5.Name = "custidp5";
            this.custidp5.Size = new System.Drawing.Size(100, 22);
            this.custidp5.TabIndex = 35;
            // 
            // custidp6
            // 
            this.custidp6.Location = new System.Drawing.Point(377, 286);
            this.custidp6.Name = "custidp6";
            this.custidp6.Size = new System.Drawing.Size(100, 22);
            this.custidp6.TabIndex = 37;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(291, 286);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(80, 16);
            this.label19.TabIndex = 36;
            this.label19.Text = "Customer ID";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(618, 286);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 16);
            this.label20.TabIndex = 39;
            this.label20.Text = "Amount";
            // 
            // amountp6
            // 
            this.amountp6.Location = new System.Drawing.Point(684, 286);
            this.amountp6.Name = "amountp6";
            this.amountp6.Size = new System.Drawing.Size(100, 22);
            this.amountp6.TabIndex = 38;
            // 
            // prodidp7
            // 
            this.prodidp7.Location = new System.Drawing.Point(377, 341);
            this.prodidp7.Name = "prodidp7";
            this.prodidp7.Size = new System.Drawing.Size(100, 22);
            this.prodidp7.TabIndex = 41;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(291, 344);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 16);
            this.label21.TabIndex = 40;
            this.label21.Text = "Product ID";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(618, 397);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 16);
            this.label22.TabIndex = 45;
            this.label22.Text = "Amount";
            // 
            // amountp8
            // 
            this.amountp8.Location = new System.Drawing.Point(684, 393);
            this.amountp8.Name = "amountp8";
            this.amountp8.Size = new System.Drawing.Size(100, 22);
            this.amountp8.TabIndex = 44;
            // 
            // prodidp8
            // 
            this.prodidp8.Location = new System.Drawing.Point(377, 397);
            this.prodidp8.Name = "prodidp8";
            this.prodidp8.Size = new System.Drawing.Size(100, 22);
            this.prodidp8.TabIndex = 43;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(291, 397);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(69, 16);
            this.label23.TabIndex = 42;
            this.label23.Text = "Product ID";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(618, 448);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(74, 16);
            this.label24.TabIndex = 50;
            this.label24.Text = "New Status";
            // 
            // statusp9
            // 
            this.statusp9.Location = new System.Drawing.Point(698, 444);
            this.statusp9.Name = "statusp9";
            this.statusp9.Size = new System.Drawing.Size(100, 22);
            this.statusp9.TabIndex = 49;
            // 
            // custidp9
            // 
            this.custidp9.Location = new System.Drawing.Point(377, 448);
            this.custidp9.Name = "custidp9";
            this.custidp9.Size = new System.Drawing.Size(100, 22);
            this.custidp9.TabIndex = 48;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(291, 448);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(80, 16);
            this.label25.TabIndex = 47;
            this.label25.Text = "Customer ID";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(574, 447);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(0, 16);
            this.label26.TabIndex = 46;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(734, 504);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(86, 16);
            this.label27.TabIndex = 56;
            this.label27.Text = "Sale Quantity";
            // 
            // qtyp10
            // 
            this.qtyp10.Location = new System.Drawing.Point(826, 501);
            this.qtyp10.Name = "qtyp10";
            this.qtyp10.Size = new System.Drawing.Size(100, 22);
            this.qtyp10.TabIndex = 55;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(517, 504);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 16);
            this.label28.TabIndex = 54;
            this.label28.Text = "Product ID";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(291, 504);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(80, 16);
            this.label29.TabIndex = 53;
            this.label29.Text = "Customer ID";
            // 
            // prodidp10
            // 
            this.prodidp10.Location = new System.Drawing.Point(592, 501);
            this.prodidp10.Name = "prodidp10";
            this.prodidp10.Size = new System.Drawing.Size(100, 22);
            this.prodidp10.TabIndex = 52;
            // 
            // custidp10
            // 
            this.custidp10.Location = new System.Drawing.Point(377, 501);
            this.custidp10.Name = "custidp10";
            this.custidp10.Size = new System.Drawing.Size(100, 22);
            this.custidp10.TabIndex = 51;
            // 
            // get_all_customers
            // 
            this.get_all_customers.Location = new System.Drawing.Point(1191, 233);
            this.get_all_customers.Name = "get_all_customers";
            this.get_all_customers.Size = new System.Drawing.Size(202, 23);
            this.get_all_customers.TabIndex = 57;
            this.get_all_customers.Text = "Get All Customers";
            this.get_all_customers.UseVisualStyleBackColor = true;
            this.get_all_customers.Click += new System.EventHandler(this.get_all_customers_Click);
            // 
            // get_all_products
            // 
            this.get_all_products.Location = new System.Drawing.Point(1191, 341);
            this.get_all_products.Name = "get_all_products";
            this.get_all_products.Size = new System.Drawing.Size(202, 23);
            this.get_all_products.TabIndex = 58;
            this.get_all_products.Text = "Get All Products";
            this.get_all_products.UseVisualStyleBackColor = true;
            this.get_all_products.Click += new System.EventHandler(this.get_all_products_Click);
            // 
            // add_complex_sale
            // 
            this.add_complex_sale.Location = new System.Drawing.Point(1215, 599);
            this.add_complex_sale.Name = "add_complex_sale";
            this.add_complex_sale.Size = new System.Drawing.Size(150, 23);
            this.add_complex_sale.TabIndex = 59;
            this.add_complex_sale.Text = "Add Complex Sale";
            this.add_complex_sale.UseVisualStyleBackColor = true;
            this.add_complex_sale.Click += new System.EventHandler(this.add_complex_sale_Click);
            // 
            // get_all_sales
            // 
            this.get_all_sales.Location = new System.Drawing.Point(987, 654);
            this.get_all_sales.Name = "get_all_sales";
            this.get_all_sales.Size = new System.Drawing.Size(150, 23);
            this.get_all_sales.TabIndex = 60;
            this.get_all_sales.Text = "Get All Sales";
            this.get_all_sales.UseVisualStyleBackColor = true;
            this.get_all_sales.Click += new System.EventHandler(this.get_all_sales_Click);
            // 
            // count_product_sales
            // 
            this.count_product_sales.Location = new System.Drawing.Point(986, 702);
            this.count_product_sales.Name = "count_product_sales";
            this.count_product_sales.Size = new System.Drawing.Size(150, 23);
            this.count_product_sales.TabIndex = 61;
            this.count_product_sales.Text = "Count Product Sales";
            this.count_product_sales.UseVisualStyleBackColor = true;
            this.count_product_sales.Click += new System.EventHandler(this.count_product_sales_Click);
            // 
            // delete_sale
            // 
            this.delete_sale.Location = new System.Drawing.Point(986, 754);
            this.delete_sale.Name = "delete_sale";
            this.delete_sale.Size = new System.Drawing.Size(150, 23);
            this.delete_sale.TabIndex = 62;
            this.delete_sale.Text = "Delete Sale ";
            this.delete_sale.UseVisualStyleBackColor = true;
            this.delete_sale.Click += new System.EventHandler(this.delete_sale_Click);
            // 
            // delete_all_sales
            // 
            this.delete_all_sales.Location = new System.Drawing.Point(986, 801);
            this.delete_all_sales.Name = "delete_all_sales";
            this.delete_all_sales.Size = new System.Drawing.Size(150, 23);
            this.delete_all_sales.TabIndex = 63;
            this.delete_all_sales.Text = "Delete All Sales";
            this.delete_all_sales.UseVisualStyleBackColor = true;
            this.delete_all_sales.Click += new System.EventHandler(this.delete_all_sales_Click);
            // 
            // delete_product
            // 
            this.delete_product.Location = new System.Drawing.Point(987, 895);
            this.delete_product.Name = "delete_product";
            this.delete_product.Size = new System.Drawing.Size(150, 23);
            this.delete_product.TabIndex = 64;
            this.delete_product.Text = "Delete Product";
            this.delete_product.UseVisualStyleBackColor = true;
            this.delete_product.Click += new System.EventHandler(this.delete_product_Click);
            // 
            // delete_customer
            // 
            this.delete_customer.Location = new System.Drawing.Point(986, 847);
            this.delete_customer.Name = "delete_customer";
            this.delete_customer.Size = new System.Drawing.Size(150, 23);
            this.delete_customer.TabIndex = 65;
            this.delete_customer.Text = "Delete Customer";
            this.delete_customer.UseVisualStyleBackColor = true;
            this.delete_customer.Click += new System.EventHandler(this.delete_customer_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(12, 607);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(152, 16);
            this.label30.TabIndex = 66;
            this.label30.Text = "Add Complex Sale (p12)";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 661);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(117, 16);
            this.label31.TabIndex = 67;
            this.label31.Text = "Get All Sales (p13)";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(12, 709);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(154, 16);
            this.label32.TabIndex = 68;
            this.label32.Text = "Count Product Sale (p14)";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(12, 761);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(111, 16);
            this.label33.TabIndex = 69;
            this.label33.Text = "Delete Sale (p15)";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(12, 808);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(136, 16);
            this.label34.TabIndex = 70;
            this.label34.Text = "Delete All Sales (p16)";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(14, 850);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(140, 16);
            this.label35.TabIndex = 71;
            this.label35.Text = "Delete Customer (p17)";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(12, 902);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(129, 16);
            this.label36.TabIndex = 72;
            this.label36.Text = "Delete Product (p18)";
            // 
            // custidp12
            // 
            this.custidp12.Location = new System.Drawing.Point(366, 601);
            this.custidp12.Name = "custidp12";
            this.custidp12.Size = new System.Drawing.Size(100, 22);
            this.custidp12.TabIndex = 73;
            // 
            // prodidp12
            // 
            this.prodidp12.Location = new System.Drawing.Point(592, 600);
            this.prodidp12.Name = "prodidp12";
            this.prodidp12.Size = new System.Drawing.Size(100, 22);
            this.prodidp12.TabIndex = 74;
            // 
            // qtyp12
            // 
            this.qtyp12.Location = new System.Drawing.Point(843, 600);
            this.qtyp12.Name = "qtyp12";
            this.qtyp12.Size = new System.Drawing.Size(100, 22);
            this.qtyp12.TabIndex = 75;
            // 
            // datep12
            // 
            this.datep12.Location = new System.Drawing.Point(1057, 600);
            this.datep12.Name = "datep12";
            this.datep12.Size = new System.Drawing.Size(100, 22);
            this.datep12.TabIndex = 76;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(280, 604);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(80, 16);
            this.label37.TabIndex = 77;
            this.label37.Text = "Customer ID";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(517, 603);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(69, 16);
            this.label38.TabIndex = 78;
            this.label38.Text = "Product ID";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(751, 603);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(86, 16);
            this.label39.TabIndex = 79;
            this.label39.Text = "Sale Quantity";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(1006, 604);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(36, 16);
            this.label40.TabIndex = 80;
            this.label40.Text = "Date";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(280, 847);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(80, 16);
            this.label41.TabIndex = 82;
            this.label41.Text = "Customer ID";
            // 
            // custidp17
            // 
            this.custidp17.Location = new System.Drawing.Point(366, 844);
            this.custidp17.Name = "custidp17";
            this.custidp17.Size = new System.Drawing.Size(100, 22);
            this.custidp17.TabIndex = 81;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(280, 899);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(69, 16);
            this.label42.TabIndex = 84;
            this.label42.Text = "Product ID";
            // 
            // prodidp18
            // 
            this.prodidp18.Location = new System.Drawing.Point(366, 896);
            this.prodidp18.Name = "prodidp18";
            this.prodidp18.Size = new System.Drawing.Size(100, 22);
            this.prodidp18.TabIndex = 83;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(310, 718);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(39, 16);
            this.label43.TabIndex = 86;
            this.label43.Text = "Days";
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // daysp14
            // 
            this.daysp14.Location = new System.Drawing.Point(366, 712);
            this.daysp14.Name = "daysp14";
            this.daysp14.Size = new System.Drawing.Size(100, 22);
            this.daysp14.TabIndex = 85;
            this.daysp14.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1996, 1099);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.daysp14);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.prodidp18);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.custidp17);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.datep12);
            this.Controls.Add(this.qtyp12);
            this.Controls.Add(this.prodidp12);
            this.Controls.Add(this.custidp12);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.delete_customer);
            this.Controls.Add(this.delete_product);
            this.Controls.Add(this.delete_all_sales);
            this.Controls.Add(this.delete_sale);
            this.Controls.Add(this.count_product_sales);
            this.Controls.Add(this.get_all_sales);
            this.Controls.Add(this.add_complex_sale);
            this.Controls.Add(this.get_all_products);
            this.Controls.Add(this.get_all_customers);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.qtyp10);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.prodidp10);
            this.Controls.Add(this.custidp10);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.statusp9);
            this.Controls.Add(this.custidp9);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.amountp8);
            this.Controls.Add(this.prodidp8);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.prodidp7);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.amountp6);
            this.Controls.Add(this.custidp6);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.custidp5);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.update_customer_status);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.pricep3);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.output);
            this.Controls.Add(this.sum_customer_saleytd);
            this.Controls.Add(this.add_simple_sale);
            this.Controls.Add(this.update_product_saleytd);
            this.Controls.Add(this.get_product);
            this.Controls.Add(this.update_customer_saleytd);
            this.Controls.Add(this.get_customer);
            this.Controls.Add(this.delete_all_products);
            this.Controls.Add(this.add_product);
            this.Controls.Add(this.delete_all_customers);
            this.Controls.Add(this.add_customer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.prodnamep3);
            this.Controls.Add(this.prodidp3);
            this.Controls.Add(this.custnamep1);
            this.Controls.Add(this.custidp1);
            this.Name = "Form1";
            this.Text = "HDTaskMAT1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox custidp1;
        private System.Windows.Forms.TextBox custnamep1;
        private System.Windows.Forms.TextBox prodidp3;
        private System.Windows.Forms.TextBox prodnamep3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button add_customer;
        private System.Windows.Forms.Button delete_all_customers;
        private System.Windows.Forms.Button add_product;
        private System.Windows.Forms.Button delete_all_products;
        private System.Windows.Forms.Button get_customer;
        private System.Windows.Forms.Button update_customer_saleytd;
        private System.Windows.Forms.Button get_product;
        private System.Windows.Forms.Button update_product_saleytd;
        private System.Windows.Forms.Button add_simple_sale;
        private System.Windows.Forms.Button sum_customer_saleytd;
        private System.Windows.Forms.ListBox output;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox pricep3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button update_customer_status;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox custidp5;
        private System.Windows.Forms.TextBox custidp6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox amountp6;
        private System.Windows.Forms.TextBox prodidp7;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox amountp8;
        private System.Windows.Forms.TextBox prodidp8;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox statusp9;
        private System.Windows.Forms.TextBox custidp9;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox qtyp10;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox prodidp10;
        private System.Windows.Forms.TextBox custidp10;
        private System.Windows.Forms.Button get_all_customers;
        private System.Windows.Forms.Button get_all_products;
        private System.Windows.Forms.Button add_complex_sale;
        private System.Windows.Forms.Button get_all_sales;
        private System.Windows.Forms.Button count_product_sales;
        private System.Windows.Forms.Button delete_sale;
        private System.Windows.Forms.Button delete_all_sales;
        private System.Windows.Forms.Button delete_product;
        private System.Windows.Forms.Button delete_customer;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox custidp12;
        private System.Windows.Forms.TextBox prodidp12;
        private System.Windows.Forms.TextBox qtyp12;
        private System.Windows.Forms.TextBox datep12;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox custidp17;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox prodidp18;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox daysp14;
    }
}

