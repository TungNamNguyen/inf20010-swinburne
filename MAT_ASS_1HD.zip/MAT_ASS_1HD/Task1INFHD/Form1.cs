﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using System.Configuration;
namespace Task1INFHD
{
  

    public partial class Form1 : Form
    {
        private string connectionString = "User Id=s103181157;Password=123456nAm#;Data Source=feenix-oracle.swin.edu.au:1521/DMS";
        private OracleConnection conn;

        public Form1()
        {
            InitializeComponent();
            conn = new OracleConnection(connectionString);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                output.Items.Add("Database connection successful.");
            }
            catch (Exception ex)
            {
                output.Items.Add("Error connecting to database: " + ex.Message);
            }
        }


        private void add_customer_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("ADD_CUST_TO_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(custidp1.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return; 
                }
                int cust_id = Convert.ToInt32(custidp1.Text);
                string cust_name = custnamep1.Text;
                output.Items.Add("Adding Customer. ID: " + cust_id + " Name: " + cust_name);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pcustid", OracleDbType.Int32).Value = cust_id;
                cmd.Parameters.Add("pcustname", OracleDbType.Varchar2).Value = cust_name;

                OracleTransaction transaction = conn.BeginTransaction();
                try
                {   
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    output.Items.Add("Customer Added OK");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void delete_all_customers_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("DELETE_ALL_CUSTOMERS_FROM_DB", conn))
            {
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                OracleParameter return_value = new OracleParameter();
                return_value.OracleDbType = OracleDbType.Int32;
                return_value.Direction = System.Data.ParameterDirection.ReturnValue;
                cmd.Parameters.Add(return_value);
                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    //int row_deleted = Convert.ToInt32(return_value.Value);
                    output.Items.Add( return_value.Value +" rows deleted");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void add_product_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("ADD_PRODUCT_TO_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(prodidp3.Text) || string.IsNullOrWhiteSpace(pricep3.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int prod_id = Convert.ToInt32(prodidp3.Text);
                string prod_name = prodnamep3.Text;
                int price = Convert.ToInt32(pricep3.Text);
                output.Items.Add("Adding Product. ID: " + prod_id + " Name: " + prod_name + " Price: " + price);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pprodid", OracleDbType.Int32).Value = prod_id;
                cmd.Parameters.Add("pprodname", OracleDbType.Varchar2).Value = prod_name;
                cmd.Parameters.Add("pprice", OracleDbType.Int32).Value = price;

                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    output.Items.Add("Product Added OK");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void delete_all_products_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("DELETE_ALL_PRODUCTS_FROM_DB", conn))
            {
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                OracleParameter return_value = new OracleParameter();
                return_value.OracleDbType = OracleDbType.Int32;
                return_value.Direction = System.Data.ParameterDirection.ReturnValue;
                cmd.Parameters.Add(return_value);
                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    //int row_deleted = Convert.ToInt32(return_value.Value);
                    output.Items.Add(return_value.Value + " rows deleted");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void get_customer_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("GET_CUST_STRING_FROM_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(custidp5.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int cust_id = Convert.ToInt32(custidp5.Text);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                OracleParameter return_value = new OracleParameter();
                return_value.OracleDbType = OracleDbType.Varchar2;
                return_value.Size = 1500; 
                return_value.Direction = System.Data.ParameterDirection.ReturnValue;
                cmd.Parameters.Add(return_value);
                OracleParameter input = new OracleParameter("pcustid", OracleDbType.Int32);
                input.Direction = System.Data.ParameterDirection.Input;
                input.Value = cust_id;
                cmd.Parameters.Add(input);
                try
                {
                    cmd.ExecuteNonQuery();
                    string customerDetails = return_value.Value.ToString();
                    //int row_deleted = Convert.ToInt32(return_value.Value);
                    output.Items.Add(customerDetails);
                }
                catch (Exception ex)
                {
              
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }
    

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void update_customer_saleytd_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("UPD_CUST_SALESYTD_IN_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(custidp6.Text) || string.IsNullOrWhiteSpace(amountp6.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int cust_id = Convert.ToInt32(custidp6.Text);
                int amount = Convert.ToInt32(amountp6.Text);
       
                output.Items.Add("Updating SalesYTD. CustomerID: " + cust_id + " Amount: " + amount);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pcustid", OracleDbType.Int32).Value = cust_id;
                cmd.Parameters.Add("pamt", OracleDbType.Varchar2).Value = amount;

                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    output.Items.Add("Update OK");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void get_product_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("GET_PROD_STRING_FROM_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(prodidp7.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int prod_id = Convert.ToInt32(prodidp7.Text);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                OracleParameter return_value = new OracleParameter();
                return_value.OracleDbType = OracleDbType.Varchar2;
                return_value.Size = 1500; 
                return_value.Direction = System.Data.ParameterDirection.ReturnValue;
                cmd.Parameters.Add(return_value);
                OracleParameter input = new OracleParameter("pprodid", OracleDbType.Int32);
                input.Direction = System.Data.ParameterDirection.Input;
                input.Value = prod_id;
                cmd.Parameters.Add(input);


                try
                {
                    cmd.ExecuteNonQuery();
                    string productDetails = return_value.Value.ToString();
                    //int row_deleted = Convert.ToInt32(return_value.Value);
                    output.Items.Add(productDetails);
                }
                catch (Exception ex)
                {

                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void add_simple_sale_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("ADD_SIMPLE_SALE_TO_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(prodidp10.Text) || string.IsNullOrWhiteSpace(qtyp10.Text) || string.IsNullOrWhiteSpace(custidp10.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int prod_id = Convert.ToInt32(prodidp10.Text);
                int quantity = Convert.ToInt32(qtyp10.Text);
                int cust_id = Convert.ToInt32(custidp10.Text);
                output.Items.Add("Adding Simple Sale. Customer ID: " + cust_id + " ProdID " + prod_id + " Quantity: " + quantity);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pcustid", OracleDbType.Int32).Value = cust_id;
                cmd.Parameters.Add("pprodid", OracleDbType.Int32).Value = prod_id;
                cmd.Parameters.Add("pqty", OracleDbType.Int32).Value = quantity;

                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    output.Items.Add("Simple Sale Added OK");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void sum_customer_saleytd_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("SUM_CUST_SALESYTD", conn))
            {
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                OracleParameter return_value = new OracleParameter();
                return_value.OracleDbType = OracleDbType.Int32;
                return_value.Direction = System.Data.ParameterDirection.ReturnValue;
                cmd.Parameters.Add(return_value);
                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    //int row_deleted = Convert.ToInt32(return_value.Value);
                    output.Items.Add("All customer totals: " + return_value.Value);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

       
        private void update_customer_status_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("UPD_CUST_STATUS_IN_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(custidp9.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int cust_id = Convert.ToInt32(custidp9.Text);
                string new_status = statusp9.Text;

                output.Items.Add("Updating Status. CustID: " + cust_id + " New Status: " + new_status);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pcustid", OracleDbType.Int32).Value = cust_id;
                cmd.Parameters.Add("pstatus", OracleDbType.Varchar2).Value = new_status;

                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    output.Items.Add("Update OK");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void update_product_saleytd_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("UPD_PROD_SALESYTD_IN_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(prodidp8.Text) || string.IsNullOrWhiteSpace(amountp8.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int prod_id = Convert.ToInt32(prodidp8.Text);
                int amount = Convert.ToInt32(amountp8.Text);

                output.Items.Add("Updating SalesYTD. ProductID: " + prod_id + " Amount: " + amount);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pprodid", OracleDbType.Int32).Value = prod_id;
                cmd.Parameters.Add("pamt", OracleDbType.Varchar2).Value = amount;

                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    output.Items.Add("Update OK");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void get_all_customers_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("CustomerPackage.GET_ALLCUST", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                OracleParameter custCursor = new OracleParameter();
                custCursor.OracleDbType = OracleDbType.RefCursor;
                custCursor.Direction = ParameterDirection.ReturnValue;
                cmd.Parameters.Add(custCursor);

                try
                {
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string customerData = $"CustID: {reader["CUSTID"]}, Name: {reader["CUSTNAME"]}, Status: {reader["STATUS"]}, SalesYTD: {reader["SALES_YTD"]}";
                        output.Items.Add(customerData); 
                    }
                    reader.Close(); 
                }
                catch (Exception ex)
                {
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void get_all_products_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("ProductPackage.GET_ALLPROD_FROM_DB", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

               
                OracleParameter prodCursor = new OracleParameter();
                prodCursor.OracleDbType = OracleDbType.RefCursor;
                prodCursor.Direction = ParameterDirection.ReturnValue;
                cmd.Parameters.Add(prodCursor);

                try
                {
                    
                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string productData = $"ProductID: {reader["PRODID"]}, Name: {reader["PRODNAME"]}, Price: {reader["SELLING_PRICE"]} , Sales_YTD: {reader["SALES_YTD"]} ";
                        output.Items.Add(productData); 
                    }

                    reader.Close(); 
                }
                catch (Exception ex)
                {
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void add_complex_sale_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("ADD_COMPLEX_SALE_TO_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(prodidp12.Text) || string.IsNullOrWhiteSpace(qtyp12.Text) || string.IsNullOrWhiteSpace(custidp12.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int prod_id = Convert.ToInt32(prodidp12.Text);
                int quantity = Convert.ToInt32(qtyp12.Text);
                int cust_id = Convert.ToInt32(custidp12.Text);
                string date = datep12.Text;
                output.Items.Add("Adding Complex Sale. Customer ID: " + cust_id + " ProdID " + prod_id + " Quantity: " + quantity + " Date " + date);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pcustid", OracleDbType.Int32).Value = cust_id;
                cmd.Parameters.Add("pprodid", OracleDbType.Int32).Value = prod_id;
                cmd.Parameters.Add("pqty", OracleDbType.Int32).Value = quantity;
                cmd.Parameters.Add("pdate", OracleDbType.Varchar2).Value = date;
                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    output.Items.Add("Complex Sale Added OK");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void count_product_sales_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("COUNT_PRODUCT_SALES_FROM_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(daysp14.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int days = Convert.ToInt32(daysp14.Text);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                OracleParameter return_value = new OracleParameter();
                return_value.OracleDbType = OracleDbType.Int32;
                return_value.Size = 1500;
                return_value.Direction = System.Data.ParameterDirection.ReturnValue;
                cmd.Parameters.Add(return_value);
                OracleParameter input = new OracleParameter("pdays", OracleDbType.Int32);
                input.Direction = System.Data.ParameterDirection.Input;
                input.Value = days;
                cmd.Parameters.Add(input);
                try
                {
                    cmd.ExecuteNonQuery();
                    string count_product_sale = return_value.Value.ToString();
                
                    output.Items.Add("Total Number of Sales" + count_product_sale);
                }
                catch (Exception ex)
                {

                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void get_all_sales_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("SalePackage.GET_ALLSALES_FROM_DB", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                
                OracleParameter saleCursor = new OracleParameter();
                saleCursor.OracleDbType = OracleDbType.RefCursor;
                saleCursor.Direction = ParameterDirection.ReturnValue;
                cmd.Parameters.Add(saleCursor);

                try
                {

                    OracleDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string saleData = $"SaleID: {reader["SALEID"]}, CustID: {reader["CUSTID"]}, ProdID: {reader["PRODID"]} , Quantity: {reader["QTY"]}, Price: {reader["PRICE"]} , Date: {reader["SALEDATE"]} ";
                        output.Items.Add(saleData); 
                    }

                    reader.Close(); 
                }
                catch (Exception ex)
                {
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void delete_sale_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("DELETE_SALE_FROM_DB", conn))
            {
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                OracleParameter return_value = new OracleParameter();
                return_value.OracleDbType = OracleDbType.Int32;
                return_value.Direction = System.Data.ParameterDirection.ReturnValue;
                cmd.Parameters.Add(return_value);
                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                   
                    output.Items.Add("Deleting Sale with the smallest ID Ok: SaleID: " + return_value.Value);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void delete_all_sales_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("DELETE_ALL_SALES_FROM_DB", conn))
            {
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
               
                OracleTransaction transaction = conn.BeginTransaction();
                try
                {
                    cmd.ExecuteNonQuery();
                    transaction.Commit();
                    
                    output.Items.Add("Deletion OK");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void delete_product_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("DELETE_PROD_FROM_DB", conn))
            {
                if (string.IsNullOrWhiteSpace(prodidp18.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int prod_id = Convert.ToInt32(prodidp18.Text);
                output.Items.Add("Deleting Product. ID: " + prod_id);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pProdid", OracleDbType.Int32).Value = prod_id;

                try
                {
                    cmd.ExecuteNonQuery();
         
                
                    output.Items.Add("Deleted Product Ok");
                }
                catch (Exception ex)
                {

                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void delete_customer_Click(object sender, EventArgs e)
        {
            using (OracleCommand cmd = new OracleCommand("DELETE_CUSTOMER", conn))
            {
                if (string.IsNullOrWhiteSpace(custidp17.Text))
                {
                    output.Items.Add("Error: Input cannot be blank.");
                    return;
                }
                int cust_id = Convert.ToInt32(custidp17.Text);
                output.Items.Add("Deleting Customer. ID: " + cust_id);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("pCustid", OracleDbType.Int32).Value = cust_id;

                try
                {
                    cmd.ExecuteNonQuery();

                    //int row_deleted = Convert.ToInt32(return_value.Value);
                    output.Items.Add("Deleted Customer Ok");
                }
                catch (Exception ex)
                {

                    output.Items.Add("Error: " + ex.Message);
                }
            }
        }

        private void label43_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
